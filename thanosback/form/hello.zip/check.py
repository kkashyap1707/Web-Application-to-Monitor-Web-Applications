import time
import os
import boto3
from botocore.vendored import requests
from influxdb import InfluxDBClient
def listf(event,context):
	user=os.getenv('user')
    url=os.getenv('url')
    res = requests.head(url)
    check = res.status_code
    status_code=int(os.getenv('status'))
    if (check==status_code):
        print ("valid")
    else:
        print ("Invalid")
        sns_client=boto3.client('sns')
        message="your website status is "+str(check) +" and response time is = "+str(requests.post(url).elapsed.total_seconds())
        send=sns_client.publish(TargetArn='arn:aws:sns:us-east-1:754068459088:yash',Message=message,Subject='pingdom')
    print (requests.post(url).elapsed.total_seconds())
    response_time=requests.post(url).elapsed.total_seconds()
    print(response_time)
    client=InfluxDBClient(host='3.95.137.53',port=8086)
    print(client.get_list_database())
    client.switch_database('new')
    body=[
    {
     "measurement":user,
     "tags":{
         "url":url
         },
      "fields":{
         "status_code":float(check),
         "response_time":response_time
         }
   }
 ]
    a=client.write_points(body)
    print(a)
    print(client.query('select * from '+user))

